chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "startCapture") {

    // Variáveis para armazenar os dados da trilha e unidade
    var trilha = '';
    var unidade = '';

    // Declara remover acentos
    function removerAcentos(texto) {
      return texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }

   // Função para capturar a trilha e unidade
function capturarTrilhaEUnidade() {
  // Loop para garantir que a trilha inserida seja um número de 1 dígito
  do {
    trilha = prompt("Por favor, selecione a Trilha (1 a 4):");
  } while (!validarNumeroDeUmDigito(trilha));

  // Loop para garantir que a unidade inserida seja um número de 2 dígitos
  do {
    unidade = prompt("Por favor, selecione a Unidade (01 a 05):");
  } while (!validarNumeroDeDoisDigitos(unidade));
}

// Função para validar número de um dígito
function validarNumeroDeUmDigito(numero) {
  return /^[1-4]$/.test(numero);
}

// Função para validar número de dois dígitos
function validarNumeroDeDoisDigitos(numero) {
  return /^[0-9]{2}$/.test(numero);
}


    // Função para validar se um número tem dois dígitos
    function validarNumeroDeDoisDigitos(numero) {
      // Verifica se o número é composto por exatamente dois dígitos e se é um número
      return /^\d{2}$/.test(numero);
    }

    // Variável para armazenar os dados das perguntas já capturadas
    var perguntasCapturadas = [];

    // Função para capturar os dados da div class="question-content"
    function capturarDados() {
      // Seleciona todas as divs com a classe "question-content"
      var divs = document.querySelectorAll('.question-content');

      // Itera sobre as divs capturadas
      divs.forEach(function(div) {
        // Ignora as divs que possuem a classe "option-feedback"
        if (!div.classList.contains('option-feedback')) {
          // Captura o texto dentro da div da pergunta atual
          var texto = div.innerText;

          // Captura o número da classe question-identifier
          var identificadorElement = div.querySelector('.question-identifier');
          if (identificadorElement) {
            var identificador = identificadorElement.innerText;
            identificador = identificador.replace(/[.\-]/g, ''); // Remove pontos e traços

            // Substitui todas as ocorrências de "Resposta incorreta." por "~"
            texto = texto.replace(/Resposta incorreta\./g, "~");
            // Substitui todas as ocorrências de "Resposta correta." por "="
            texto = texto.replace(/Resposta correta\./g, "=");

            // Remove as quebras de linha e transforma em uma única linha apenas para topic-content-body
            var topicContentBodies = div.querySelectorAll('.topic-content-body');
            topicContentBodies.forEach(function(topicContentBody) {
              var topicContentBodyText = topicContentBody.innerText.replace(/\n/g, ' ');
              texto = texto.replace(topicContentBody.innerText, topicContentBodyText);
            });

            // Verifica se a pergunta já foi capturada
            if (!perguntaJaCapturada(identificador)) {
              // Adiciona os dados da pergunta ao array de perguntas capturadas
              perguntasCapturadas.push(identificador + '\n' + texto);
            }
          }
        }
      });
    }

    // Função para verificar se a pergunta já foi capturada
    function perguntaJaCapturada(identificador) {
      return perguntasCapturadas.some(function(pergunta) {
        return pergunta.startsWith(identificador + '\n');
      });
    }

    // Função para clicar no botão "Próximo"
    function clicarProximo() {
      // Seleciona o botão "Próximo" com a classe específica
      var botaoProximo = document.querySelector('.v-icon.notranslate.mdi.mdi-chevron-right.theme--light');

      // Se o botão existir, clique nele
      if (botaoProximo) {
        botaoProximo.click();
      } else {
        console.log("Não há mais botões 'Próximo'."); // Mensagem exibida quando não houver mais botões "Próximo"
      }
    }

    // Função para repetir a captura e o clique até não haver mais botões "Próximo"
    function repetir() {
      // Aguarda um pequeno intervalo de tempo para garantir que a próxima página seja totalmente carregada
      setTimeout(function() {
        // Captura os dados das questões atuais
        capturarDados();
    
        // Clica em "Próximo"
        clicarProximo();

        // Se houver botão "Próximo", repita
        if (document.querySelector('.v-icon.notranslate.mdi.mdi-chevron-right.theme--light')) {
          repetir();
        } else {
          // Se não houver mais botões "Próximo", salva os dados capturados em um arquivo de texto
          salvarDadosEmArquivo();
        }
      }, 1000); // Altere o valor do intervalo conforme necessário
    }

    // Função para remover linhas em branco do texto
    function removerLinhasEmBranco(texto) {
      return texto.replace(/^\s*[\r\n]/gm, '');
    }

    // Função para remover expressões específicas do texto
    function removerExpressoes(texto) {
      // Expressões a serem removidas
      var expressoes = [
        /\b\d+ de \d+ perguntas\b/g, // Expressões como "1 de 5 perguntas", "2 de 5 perguntas", etc.
        /\bPróximo\b/g, // Expressão "Próximo"
        /\bVoltar\b/g // Expressão "Voltar"
      ];

      // Aplica a remoção das expressões
      expressoes.forEach(function(expressao) {
        texto = texto.replace(expressao, '');
      });

      return texto;
    }

    // Função para salvar os dados capturados em um arquivo de texto
    function salvarDadosEmArquivo() {
      // Obtém o título da página e remove os acentos
      var tituloPagina = removerAcentos(document.title);

      // Remove linhas em branco dos dados capturados e expressões específicas
      var dadosFormatados = removerLinhasEmBranco(perguntasCapturadas.join('\n'));
      dadosFormatados = removerExpressoes(dadosFormatados);

      // Adiciona a trilha e unidade nas duas primeiras linhas do arquivo
      dadosFormatados = "Trilha " + trilha + "\n" + unidade + "\n" + dadosFormatados;

      // Cria um objeto Blob contendo os dados formatados, com a codificação UTF-8
      var blob = new Blob([dadosFormatados], { type: 'text/plain;charset=utf-8' });

      // Cria um link para download do arquivo
      var link = document.createElement('a');
      link.href = URL.createObjectURL(blob);

      // Define o nome do arquivo como o título da página com a extensão ".txt"
      link.download = tituloPagina.replace(/[^a-z0-9]/gi, '_').toLowerCase() + '.txt';

      // Clica no link para iniciar o download do arquivo
      link.click();
    }

    // Chama a função para capturar a trilha e unidade antes de iniciar o processo
    capturarTrilhaEUnidade();

    // Chama a função repetir para iniciar o processo
    repetir();
  }
});
